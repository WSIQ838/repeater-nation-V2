## 2026-09-30 — Fix Base44 Monitor Grid Publish Syntax

- Corrected a malformed literal `\\n` sequence in `src/components/radio/RadioMonitorGrid.jsx` that caused Vite/esbuild to fail at line 49.
- Applied the same exact correction to the Base44 sandbox so the editor and GitHub source match.
- Re-ran `npm run build`: PASS. Only the existing Browserslist freshness warning remains.

## 2026-09-30 — Fix Admin Panel Rate Limit

- Reduced Admin Dashboard stats request load by replacing repeated 500-record pagination across Users, Repeaters, and Reports with bounded single reads.
- This removes the large request burst that could trigger Base44 `Rate limit exceeded` when opening Admin.
- Preserved the existing dashboard statistics and recent-audit presentation for datasets within the dashboard read bound.
- Production build verified successfully; only the existing Browserslist freshness warning remains.

## 2026-09-30 — Fix Admin Panel Access

- Fixed Admin Panel authorization so the `admin` role is accepted directly instead of depending on a potentially stale or missing `RolePermission` record for `admin.view`.
- Applied the matching frontend permission fallback so the Admin route and secure `admin-api` gateway use the same administrator-role behavior.
- Re-ran `npm run build`: PASS. Only the existing Browserslist freshness warning remains.

## 2026-10-01 — Web Radio Final Verification Pass

- Hardened public monitor access so anonymous monitor sessions can only join administrator-selected monitor-grid channels.
- Cleaned monitor-grid stale audio synchronization references while preserving receive-only monitor behavior and the persistent floating radio widget.
- Normalized all PTT cleanup releases to send canonical channel/zone/number recovery data.
- Tightened PTT floor renewal from 10s to 8s for faster recovery when a transmitter drops.
- Added direct-call LiveKit reconnect/reconnected handling and faster active-call state polling.
- Added a server-side guard against activating an already-connected direct-call room twice.
- Verified the frontend with npm run build successfully and ran ESLint on the changed radio files successfully. Only the existing Browserslist freshness warning remains.
- Known limitation retained: the monitor grid uses one receive session per configured channel; replacing that with a shared multi-track LiveKit connection would be a larger architectural change and was not made in this pass.

## 2026-09-30 — Web Radio Hardening Follow-up

- Restricted anonymous monitor sessions to channels explicitly selected by administrators in RadioMonitorConfig, while continuing to block admin-only and elevated-role zones from public monitoring.
- Removed dead monitor-grid code that attempted to coordinate audio with the floating widget through a browser event; monitor tiles now own their receive volume directly.
- Preserved the persistent floating radio widget, LiveKit transport, PTT floor control, direct calls, and existing member access rules.
- GitHub commits: 2dd5014773665f5d495d398ea9945cf1ef8c2dfd and 2c62c733704634eb849cb6b61bca40891750920a.
- Discord changelog publishing remains wired to the existing app-publish workflow.

## 2026-09-30 — Web Radio Reliability and Performance Pass

- Cleaned stale direct-call conflicts before starting a new direct call, so orphaned active records no longer block a member from placing another call.
- Reduced direct-call/presence refresh traffic from 10 seconds to 15 seconds while keeping caller answer-state polling at 2 seconds.
- Kept LiveKit as the realtime source for radio/direct-call participant presence and ignored `rn-monitor-*` identities in the member roster.
- Preserved channel/zone access checks, admin-only restrictions, verified-callsign rules, LiveKit PTT floor control, microphone/speaker settings, and radio widget behavior.
- The website radio remains a persistent widget; no dedicated radio page was introduced.
- GitHub commits: 7faafdacf62242c1ca1898b720d001fe1da7b023 and 6519aa5b131b8de14f3c67c307a2c892750a1e8c.

## 2026-09-30 — Web Radio Reliability and Performance Pass

- Cleaned stale direct-call conflicts before starting a new direct call, so orphaned active records no longer block a member from placing another call.
- Reduced direct-call/presence refresh traffic from 10 seconds to 15 seconds while keeping caller answer-state polling at 2 seconds.
- Kept LiveKit as the realtime source for radio/direct-call participant presence and ignored `rn-monitor-*` identities in the member roster.
- Preserved channel/zone access checks, admin-only restrictions, verified-callsign rules, LiveKit PTT floor control, microphone/speaker settings, and radio widget behavior.
- The website radio remains a persistent widget; no dedicated radio page was introduced.
- GitHub commits: 7faafdacf62242c1ca1898b720d001fe1da7b023 and 6519aa5b131b8de14f3c67c307a2c892750a1e8c.

## 2026-09-28 — XP System Audit and Leaderboard Calculation Fixes

- Moved leaderboard XP aggregation into the server-side `leaderboard-xp` backend function so public leaderboard pages no longer directly query the admin-only `XpAdjustment` entity.
- Corrected period handling so contact logs, net check-ins, net sessions, badges, POTA activations/contacts, club memberships, club creation, event creation, and manual XP adjustments are evaluated against the selected period.
- Added historical net attendance calculation from `NetControlCheckIn` and `NetControlSession` instead of treating lifetime `NetStreak` counters as period activity.
- Fixed canonical callsign verification handling to use the verified/active `Callsign` records rather than relying on the Profile `license_status === "Active"` spelling.
- Prevented automatically generated POTA and Net Control Event records from also earning separate event-creation XP.
- Added anti-farming caps of five club-creation XP awards and ten manual community-event XP awards per user.
- Added additional low-abuse XP opportunities: 10 XP for an approved repeater photo (capped at 10 per user), 10 XP for an approved equipment submission (capped at 20), 2 XP for a repeater comment with a per-repeater-per-day anti-spam key, and 2 XP for completed Web Radio direct calls with a three-per-day cap.
- Kept one-time profile completion and verified-callsign XP in All Time only unless a trustworthy period-specific award timestamp exists.
- Updated the full Leaderboard and dashboard Leaderboard widget to use the same server-side calculation source, keeping their scores consistent.
- Production frontend build verified successfully; only the existing Browserslist/caniuse-lite freshness warning remains.
- Live backend invocation could not be independently verified from the sandbox command runner because ad-hoc Base44 CLI/function commands timed out; no live-result claim is being made.
- Checkpoint: 1ca5a9f7c9b1d73a2707dcab0f2584071cee4732.

## 2026-09-28 — Two-Day Repeater Nation Development Summary

### 2026-09-28 — Emergency & Situational Awareness / Data Reliability

- Completed a broad Emergency & Situational Awareness audit covering the frontend map, backend aggregation, radius/ZIP filtering, refresh behavior, upstream error handling, and official data feeds.
- Fixed Emergency Map population filtering so valid 5-digit ZIP searches work and NWS alert polygons and wildfire perimeters are geographically scoped to the selected radius.
- Fixed the Emergency Map backend runtime error caused by hasCenter being referenced before initialization.
- Updated repeater loading to use bounded GMRS/HAM geographic queries instead of repeatedly scanning the full repeater database.
- Improved NWS alert retrieval and local geographic filtering so active alerts populate reliably.
- Added/updated Weather Stations using NWS point/station observations and limited observation requests to nearby stations to reduce upstream request load.
- Added/updated USGS Water Gauges using the current Water Data API path, with nearby filtering and map markers.
- Fixed AirNow PM2.5 AQI contour timestamp handling for numeric epoch timestamps so current smoke/AQI contours are no longer discarded.
- Fixed USGS earthquake timestamp handling for epoch timestamps so recent earthquakes populate correctly and remain subject to the 24-hour freshness rule.
- Improved wildfire population handling so active NIFC incidents/perimeters are not incorrectly discarded because of stale individual update timestamps.
- Added upstream-source error reporting so one failed official feed does not hide successfully returned emergency layers.
- Added evacuation-warning/order centroid dots with stronger polygon styling and alert popups.
- Fixed NASA GIBS VIIRS satellite hotspot rendering, including explicit WMS TIME, WMS 1.1.1 compatibility, NOAA-21/NOAA-20/Suomi-NPP thermal-anomaly layers, and date-based layer remounting.
- Improved satellite hotspot visibility with full tile opacity, stronger brightness/saturation/contrast, and a dedicated Satellite Hotspot legend indicator.
- Added/retained Emergency Map layers for weather alerts, earthquakes, GMRS/HAM repeaters, wildfire incidents/perimeters, shelters, weather stations, water gauges, Air Quality/Smoke, satellite hotspots, and evacuation warnings.
- Refined the Emergency Map layout with full-width map/stats presentation, collapsible Map Filters and Stats sections, responsive filter visibility, and professional compact map markers.
- Improved the user's GPS/location marker so it is clearly distinguishable from water gauges and other emergency markers.
- Verified the application production build after the latest emergency-map visibility changes; only the existing Browserslist/caniuse-lite freshness warning remains.

### 2026-09-27 — Web Radio, SDR, FCC, and Platform Reliability

- Added the Web Radio animated icon system with admin-configurable GPS, satellite, signal, network, scan, tower, Bluetooth, battery, animation, color, opacity, stroke, position, size, and visibility controls.
- Updated the radio face display formatting to use CH. channel prefixes and ZONE- zone prefixes.
- Reworked Radio PIP/popout sizing and panel placement so Incoming Call, Call a Member, Who's On — Nation Wide, Calling, Direct Call, and Radio Settings remain attached to and visible above the radio face.
- Restyled radio call/member dialogs and the active Direct Call display to match the Repeater Nation radio/callsign visual treatment without changing LiveKit call behavior.
- Reduced Web Radio, Messages, and floor-state polling intervals to reduce Base44 request amplification while keeping realtime subscriptions as the primary path.
- Optimized radio-presence and radio-direct-call backend queries to avoid unnecessary global scans and LiveKit requests.
- Added a real Pause control to local FCC ULS full imports for GMRS and HAM, preserving the current FCC cursor so paused imports can resume instead of restarting.
- Fixed Admin Callsign account synchronization so existing canonical callsign records with missing radio-service data are correctly updated and User callsign/service fields stay synchronized.
- Preserved the separate selected-member re-verification and missing-callsign workflows while keeping resync focused on filling missing callsign fields.
- Updated the public SDR map-linked list to follow the map viewport and added optional browser-location centering and distance sorting.
- Updated Admin → SDR Streams so mapped streams follow the live map viewport while preserving moderation/search/status controls.
- Fixed Admin Session Active counts for legacy accounts and staff-role matching while guarding against invalid/future activity timestamps.
- Restored the original compact Radio Settings dialog presentation before subsequent radio panel integration work.
- Removed the public API promotion section from the home page while preserving the API, API docs, and API management functionality.
- Added/maintained development-log documentation for the completed changes and preserved unrelated Repeater Nation functionality.

## 2026-09-28 — Emergency Map Evacuation Dot Visibility Fix

- Added a visible red evacuation marker dot at the center of each evacuation-warning/order polygon.
- Kept the evacuation polygon itself visible with a stronger border and fill so the affected area remains clear.
- The dot uses a white outline for contrast and opens the same evacuation alert details when selected.
- Preserved the existing NWS-derived evacuation detection, alert filtering, and all unrelated emergency layers.
- GitHub commit: 054274e5421b506a0394f318ae81115f2cbfd38a.

## 2026-09-28 — Emergency Map Satellite Hotspot Rendering Fix

- Fixed the NASA GIBS VIIRS satellite hotspot layer so it is enabled by default instead of starting hidden.
- Updated the GIBS WMS request to use the explicit uppercase `TIME` parameter and WMS 1.1.1 compatibility, with the default style explicitly selected.
- Added the Suomi-NPP VIIRS 375m day/night thermal-anomaly layer alongside NOAA-21 and NOAA-20 to provide an additional current satellite source.
- Added stable layer keys tied to the satellite date so the Leaflet WMS layers remount cleanly when the date changes.
- Preserved the existing wildfire incidents/perimeters, AirNow, NWS, USGS, repeater, shelter, weather-station, and evacuation layers.
- GitHub commit: 4368910a4da0330b6bb5565208bf6c7eeed09cdb.

## 2026-09-28 — Emergency Air Quality PM2.5 Contour Fix

- Fixed AirNow PM2.5 contour timestamp handling in the Emergency & Situational Awareness backend.
- AirNow contour Timestamp values can be numeric epoch milliseconds; the previous ISO-date parser treated those values as invalid and discarded the returned contours.
- Updated the freshness check to support epoch seconds, epoch milliseconds, and parseable date strings while retaining the 12-hour freshness window.
- Preserved the existing AirNow geographic filtering, map layer, and other Emergency Map data sources.
- GitHub commit: e06780f48646fa5db5a6de2b74798d7ad8d05bc8.

## 2026-09-28 — Emergency Weather Alerts and Air Quality Population Fix

- Changed NWS active-alert retrieval to use the complete official `/alerts/active` feed, then apply the existing center/radius geometry filtering locally. This avoids relying on the point-filtered request for population.
- Fixed AirNow contour freshness handling so numeric epoch-millisecond `Timestamp` values are converted correctly before the 12-hour freshness check.
- Verified the current AirNow contour query returns live PM2.5 AQI zones and the NWS active feed returns current alert records.
- Verified `npm run build` succeeds; only the existing Browserslist/caniuse-lite freshness warning remains.
- Preserved all other Emergency Map data sources and behavior.

## 2026-09-28 — Emergency Audit Scan Corrections and Satellite Hotspot Fix

- Corrected `base44/functions/emergency-intel/entry.ts` Weather Stations NWS point URL: replaced invalid JavaScript `chr(44)` with a normal comma, eliminating the per-refresh `ReferenceError`.
- Corrected `base44/shared/fccUlsParser.ts` so `joinHdEn()` preserves `lastActionDate`, allowing FCC daily updates to populate `FccLicense.last_transaction_date`.
- Removed unreachable duplicate-cleanup code below the intentional external `deleteIds` return in `base44/functions/cleanup-sdr-duplicates/entry.ts`.
- Corrected the Emergency Map satellite hotspot WMS integration to pass an explicit recent `TIME` parameter through React Leaflet's supported `params` prop for NASA GIBS VIIRS NOAA-20 and NOAA-21 layers.
- Verified `npm run build` succeeds; only the existing Browserslist/caniuse-lite freshness warning remains.
- Preserved unrelated Emergency Map layers and Repeater Nation functionality.

## 2026-09-28 — Emergency Situational Awareness Full Audit Fixes

- Audited the `/tools/emergency` frontend, `emergency-intel` backend aggregation, map layer rendering, location flow, radius filtering, refresh behavior, and official upstream data integrations.
- Replaced the full repeater-database scan on every Emergency Map refresh with bounded GMRS/HAM queries around the selected location/radius, while retaining a bounded fallback when no center is selected.
- Changed NWS active-alert requests to use the official point-filtered endpoint when a location is available, reducing unnecessary nationwide alert retrieval while preserving nationwide fallback behavior without a selected center.
- Migrated the USGS Water Data latest-continuous request from the older `v0` path to the current documented `v1` API path.
- Added source-specific upstream failure details so the Emergency Map identifies which official feed failed instead of displaying only a generic warning.
- Preserved the existing map layers, radius controls, markers, location behavior, refresh cadence, and unrelated Repeater Nation functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map GPS Location Marker Visibility

- Increased the **Your location** GPS marker size for easier visibility on the map.
- Strengthened the white outline and shadow while keeping the blue location pin treatment.
- Preserved all map behavior, popups, location filtering, and unrelated emergency map functionality.

## 2026-09-28 — Emergency Map GPS Location Marker

- Changed the Emergency & Situational Awareness map's **Your location** marker from a plain blue dot to a blue GPS-style pin with a white center ring.
- Kept the existing blue location color and white outer contrast so it remains distinct from water gauges and other map markers.
- Preserved location lookup, map centering, radius filtering, popups, and all unrelated emergency map functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Collapsible Filters and Stats

- Converted Map Filters into a collapsible dropdown-style section within the Live Emergency Map card.
- Converted Stats into a collapsible dropdown-style section below the map.
- Map Filters starts open for quick access; Stats starts collapsed to keep the map workspace compact.
- Preserved all emergency map data sources, layers, markers, popups, and unrelated Repeater Nation functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Layout Refinement

- Moved Map Filters into the same card as the Live Emergency Map heading, description, ZIP/radius controls, and refresh/location controls.
- Moved Stats below the map in a full-width card instead of the right sidebar.
- Preserved all emergency map data sources, layers, markers, popups, and unrelated Repeater Nation functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Sidebar Cleanup

- Removed the duplicate right-sidebar “Live Emergency Map” card and its “Live situational awareness for your selected area.” subtitle.
- Kept the Stats and Map Filters cards in the right sidebar unchanged.
- Preserved the map, controls, data layers, markers, popups, and unrelated Repeater Nation functionality.

## 2026-09-28 — Emergency Map Watch Duty-Inspired Marker Refresh

- Updated the Emergency & Situational Awareness map markers to follow the clean, compact visual language seen in Watch Duty's map legend: small color-coded circular markers, strong white edge contrast, simple high-contrast glyphs, and minimal visual chrome.
- Removed the previous rounded-square marker treatment and reduced marker footprint so dense emergency map areas remain readable.
- Kept Repeater Nation's own icon artwork and color mapping rather than copying Watch Duty artwork or branding.
- Added an in-map legend using the same compact circular color language so users can identify emergency layers at a glance.
- Preserved all emergency data sources, layers, popups, filtering, refresh behavior, and unrelated Repeater Nation functionality.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Earthquake 24 Hour Freshness Enforcement

- Added strict 24-hour freshness enforcement to USGS earthquake records before they reach the Emergency Map.
- Earthquakes are now automatically excluded when their event time is older than 24 hours or missing/invalid.
- The Emergency Map continues to use the USGS all-day feed, with the new timestamp filter preventing stale events from remaining visible.
- Repeater, shelter, weather-alert, and wildfire freshness behavior remains unchanged.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Satellite Fire Hotspots

- Added a Satellite Fire Hotspots layer using NASA GIBS and VIIRS NOAA-20 thermal-anomaly imagery.
- Added a map toggle and dedicated hotspot information panel explaining the limitations of satellite thermal detections.
- Kept NIFC wildfire incidents and perimeters as the authoritative incident/perimeter layers already in the map; satellite hotspots are an additional situational-awareness signal.
- Added Flaticon licensing guidance to the Emergency Map source/footer area so any future downloaded Flaticon marker assets are accompanied by the required author attribution when using the free license.

## 2026-09-28 — Emergency Map Air Quality / Smoke Layer

- Added current EPA AirNow PM2.5 AQI contour coverage to the Emergency & Situational Awareness map using the public EPA ArcGIS service.
- Added an Air Quality / Smoke layer toggle, AQI category styling, map popups, zone counts, and a dedicated air-quality summary panel.
- The layer is spatially scoped to the selected location/radius when a location or ZIP is available and uses recent contour timestamps.
- AirNow data is labeled as preliminary and not fully validated, consistent with EPA's data guidance.
- Preserved all existing NWS, USGS, NIFC, FEMA, weather-station, water-gauge, repeater, ZIP search, radius, refresh, and professional SVG marker functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Evacuation Warnings / Orders

- Added an Evacuation Warnings / Orders layer to the Emergency & Situational Awareness map.
- The layer derives evacuation-related polygons from the current official active alert feed already used by the map, including evacuation warnings, orders, and shelter-in-place/leave-area language when an official polygon is present.
- Added distinct warning/order styling, map popups, a summary count, and a dedicated evacuation panel with issued/expiration times.
- Clearly labeled the coverage as alert-derived rather than a complete nationwide static evacuation-zone database, because evacuation-zone publishing varies by jurisdiction.
- Preserved the existing NWS alerts, USGS, NIFC, FEMA, AQI, satellite hotspot, repeater, ZIP search, radius, refresh, and professional SVG marker functionality.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Situational Layers and Professional Markers

- Replaced the Emergency Map's emoji-style map markers with clean vector-style SVG markers for location, shelters, repeaters, earthquakes, wildfires, weather stations, and water gauges.
- Added live National Weather Service station observations near the selected location, including temperature, humidity, wind, conditions, observation time, and distance.
- Added live USGS water-gauge observations using the modern USGS Water Data APIs, filtered to recent observations and the selected map radius.
- Added Weather Stations and Water Gauges layer controls, map markers, summary counts, popups, and nearby lists.
- Preserved existing wildfire 24-hour freshness, earthquake 24-hour freshness, weather alerts, shelters, repeaters, ZIP search, radius controls, and 60-second refresh.
- Production build verified successfully.

## 2026-09-27 — Public SDR Map-Linked Nearby List

- Updated `/sdr` so the public SDR stream list follows the current map viewport instead of always showing every approved stream.
- Added a Find My Location control that uses browser geolocation, centers the SDR map on the visitor, and sorts the visible receiver list by distance.
- Added distance-in-miles to mapped SDR cards when the visitor shares location.
- Only approved streams remain publicly visible; unmapped streams are not treated as nearby map results.
- Existing SDR submission and moderation behavior remains unchanged.
- Production build verified successfully.

## 2026-09-27 — Admin SDR Map-Linked Location List

- Updated Admin → SDR Streams so the All Streams list is linked to the live map viewport.
- Panning or zooming the map now changes which mapped SDR streams appear in the admin list.
- Added Find My Location using the browser's location permission; the map centers on the operator and mapped SDR streams are sorted by distance in miles.
- The admin map includes all mapped SDR records, including pending/rejected records, so moderation can be managed geographically; existing public visibility rules remain unchanged.
- Added a visible current-map count and mapped/total stream counts.
- Kept search, status filtering, approve/reject, and delete controls intact.
- Production build verified successfully.

## 2026-09-27 — Admin Session Presence Counts Fix

- Fixed the Admin header's live Session Active counts so legacy accounts with a missing `account_status` are treated as active, matching the Admin Users page behavior.
- Made staff-role matching case-insensitive and included the `staff` role alongside admin, super_admin, and moderator.
- Added protection against future-dated or invalid `last_active` timestamps being counted as currently active.
- Kept the lightweight presence endpoint and 30-minute activity window intact to avoid adding unnecessary load.
- Production build verification follows.

## 2026-09-27 — Restore Radio Settings Dialog

- Restored Radio Settings to the original dialog presentation used before the inline-panel change.
- Restored the original compact `max-w-sm` dialog styling, header, and dialog footer behavior.
- Kept the current Radio Settings controls and functionality, including layout selection, PTT binding, audio processing, Radio EQ, microphone/speaker selection, and Roger beep controls.
- No other radio panels or radio behavior were changed.
- Production build verified successfully.

## 2026-09-27 — Radio Animated Icon System

- Added an admin-configurable Animated Radio Icons section to the Web Radio layout editor.
- Added built-in radio-style icons for GPS/location, GPS searching, satellite, signal strength, network/Wi-Fi, channel scan, radio tower, Bluetooth, and battery.
- Added selectable Pulse, Spin, Float, Blink, or no animation, plus color, opacity, stroke width, visibility, drag positioning, and resizing.
- Icons are stored inside each RadioLayout's existing controls JSON, so no new database entity is required and existing layouts remain compatible.
- Animated icons render directly on the live radio face and travel with the RadioWidget/PIP.
- Production build verified successfully.

## 2026-09-27 — Radio Display Channel and Zone Prefixes

- Updated the radio face channel-number display to use the `CH.` prefix (for example, `CH. 1`).
- Updated the radio face zone display to use the `ZONE-` prefix with no space (for example, `ZONE-GMRS`).
- Kept the underlying channel and zone values unchanged; this is a display-only formatting change.
- Production build verified successfully.

## 2026-09-27 — Radio PIP Panel Visibility Fix

- Increased the default Radio PIP window from 300×470 to 340×760 so the inline panels have real viewport space above the radio face instead of being clipped outside the PIP viewport.
- Kept the radio face anchored at the bottom of the PIP window so the six attached panels can open above it.
- Production build verified successfully.

- Adjusted the popped-out RadioWidget layout so the radio face sits at the bottom of the PIP window.
- This reserves visible space above the radio face for Incoming Call, Call a Member, Who's On — Nation Wide, Calling, Direct Call, and Radio Settings.
- Kept all six panels attached to the RadioWidget and preserved existing radio behavior.
- Production build verified successfully.

## 2026-09-27 — Radio Panels Made Part of Popout Widget

- Moved Radio Settings from a document-level dialog to an inline panel rendered inside the RadioWidget itself.
- Kept Incoming Call, Call a Member, Who's On — Nation Wide, Calling, and Direct Call as inline panels attached to the same widget container.
- Updated the popout window body to allow the attached panels to remain visible instead of clipping them.
- All six panels now travel with the radio when it is popped out/PIP.
- Production build verified successfully.

## 2026-09-27 — Radio Panels Support Popout / PIP

- Updated the popped-out Repeater Nation radio container to remain positioned and overflow-visible so the Incoming Call, Call a Member, Who's On — Nation Wide, Calling, and Direct Call panels can render correctly from the popout radio.
- Radio Settings no longer forces the radio to pop back in before opening, allowing settings to be used while the radio is popped out/PIP.
- Preserved existing radio, presence, direct-call, and LiveKit behavior.
- Production build verified successfully.

## 2026-09-27 — Incoming Call Panel Moved Above Radio Face

- Moved the Incoming Call panel from the top of the radio widget to the same `bottom-full` position used by the other radio call panels.
- Kept the existing incoming-call controls and behavior unchanged.
- Production build verified successfully.

## 2026-09-27 — Radio Call Panels Positioned Above Radio

- Changed Who's On — Nation Wide, Call a Member, and active DIRECT/CALLING panels from centered modal dialogs to compact radio-style overlays.
- Positioned the panels directly above the Repeater Nation radio widget so they stay visually attached to the radio.
- Matched the incoming-call treatment with the same bordered panel, orange status label, icon treatment, compact layout, and dark radio styling.
- Added compact close/end-call controls while preserving existing member filters, calling behavior, and direct-call functionality.
- No unrelated radio, presence, or LiveKit behavior was changed.

## 2026-09-27 — Reduce Background Polling During Rate-Limit Recovery

- Verified there are **0 running FCC full-import jobs**; the previously identified concurrent FCC import storm is stopped.
- Reduced Web Radio direct-call/presence polling from every 2 seconds to every 5 seconds.
- Reduced the Web Radio floor-state recovery poll from every 4 seconds to every 8 seconds; realtime floor updates remain the primary path.
- Reduced Messages recovery polling from every 5 seconds to every 15 seconds; the existing realtime Message subscription remains responsible for immediate updates.
- These changes reduce Base44 request volume without changing radio call behavior, message delivery, or FCC import data.
- Flight Radar's external ADS-B polling was not changed because it does not use the Base44 data layer for its live feed.

## 2026-09-27 — Add Pause Control to Local FCC ULS Imports

- Added a real **Pause** button to the Local FCC ULS database full-import controls for GMRS and Amateur (HAM), including imports already running in the background or started from another page session.
- Pausing marks the active `FccImportRun` as `paused` and preserves the current FCC cursor so the import can be resumed later without restarting from the beginning.
- Updated the FCC import worker to recognize paused runs, resume them when explicitly started again, and preserve a user-requested pause if the current worker invocation finishes after the pause request.
- Existing automatic resume-on-page-load remains limited to runs with `status=running`, so paused imports stay paused until the administrator chooses **Resume Full Import**.
- The importer now waits 1.5 seconds between worker requests and stops automatic retry after a rate-limit response, preventing a long import from consuming request capacity needed by the rest of the website.
- Added a backend singleton guard so only one full FCC import can run per radio service; paused imports require an explicit Resume action and stale browser tabs cannot silently restart them.
- On 2026-09-27, six concurrent GMRS full-import runs were found and paused after they were producing repeated `Rate limit exceeded` errors.
- No FCC license records, lookup behavior, daily-update behavior, or unrelated admin functionality was changed.

## 2026-09-27 — Consolidate Web Radio Direct-Call Entity

- Removed the duplicate lowercase `base44/entities/radio-direct-call.jsonc` definition.
- Kept the authoritative `base44/entities/RadioDirectCall.jsonc` definition, including its caller/recipient/admin RLS rules.
- No frontend direct-call behavior, call state, LiveKit room handling, or other radio functionality was changed in this cleanup.
- Verification: source/entity state was re-read after the cleanup; a production/browser build is being run after the change.

## 2026-09-24 — Fix Admin Reverify "Account No Longer Exists" Lookup

- Fixed the Admin → Users callsign action lookup so a valid member is not incorrectly treated as missing when the direct User.get() lookup returns no record.
- The admin API now falls back to the same full User collection used by the Admin Users list before returning **User not found**.
- This keeps individual **Reverify** and other row-level callsign actions aligned with the member list while still returning not found when the account truly does not exist.
- The existing **Reverify selected** workflow remains available for choosing specific members.
- **Resync all callsigns** remains separate and only fills missing callsigns; it does not perform FCC verification.
- Verification: updated source was committed to GitHub and re-read. No browser build or production verification transaction was run.

## 2026-09-24 — Net Control Computer Import Format Instructions

- Net Control → Create Net → **Import from Computer** now shows the recommended CSV table layout directly in the import screen.
- The instructions identify **Callsign** as required and **Name**, **Location**, **Station Type**, and **Notes** as optional.
- Added a sample table and example CSV so users can see one station per row and the expected header format.
- Clarified that spreadsheets should be saved/exported as **CSV** before importing and that column order may vary when recognized headers are used.
- JSON import remains supported.
- Verification: updated source was committed to GitHub and re-read after the change. No browser build or production deployment was run.

## 2026-09-24 — Net Control Computer Roster Import

- Net Control → Create Net now separates roster sources into **Use Saved Roster** and **Import from Computer**.
- The computer import accepts **CSV** and **JSON** files and reads callsign plus optional name, location, station type, and notes fields.
- Imported stations are loaded into the net roster for review/editing before the net is saved.
- Existing saved-roster, club-sync, custom-roster, and no-roster workflows remain available.
- The imported file is processed in the browser; no file is uploaded to the server just to parse the roster.
- Verification: updated source was committed to GitHub and re-read after the change. No browser build or production deployment was run.

## 2026-09-24 — Admin Re-verification Selection and Net Control Roster Import

- Admin → Users now makes the callsign re-verification workflow explicitly selective: administrators can check the members they want and use **Reverify selected**.
- Accounts with no callsign available from the legacy User field, canonical Callsign data, approved CallsignAccess, or Profile are not selectable for FCC/ULS re-verification; they remain visible for repair.
- The **Resync all callsigns** repair workflow remains separate and only fills missing User.callsign values without performing verification.
- Net Control → Create Net now clearly labels the **Roster / Import** tab and the saved-roster option as **Import Saved Roster**.
- A saved roster can be selected and imported into the new net, with the imported station count shown before saving.
- Existing club roster sync, custom rosters, and saved roster management remain available.
- Verification: updated source files were committed to GitHub and re-read after changes. No browser build or production deployment was run.

## 2026-09-27 — Web Radio Who's On + Direct Calling

### Member-selectable radio presence filters
- Added independent member-selected filters for Who's On and Call lists, persisted per user/browser.

### Member-selectable Radio EQ
- Added a real Radio EQ selector to each member's Radio Settings.
- Members can choose from the saved admin radio presets (including Police Radio, GMRS Walkie-Talkie, HAM Mobile, and Clean Voice when present).
- The selected EQ is stored per user/browser and applied only to that member's radio audio; it does not change the site-wide admin default.

### Direct-call stale-session cleanup
- Changed direct-call presence to verify that an active call's LiveKit private room actually has participants before marking either member as In Call.
- Empty private call rooms are automatically marked ended after a short grace period, preventing ghost calls from appearing when nobody is connected.
- Ringing calls older than 60 seconds are automatically marked missed.
- Renamed the member radio settings label from "Shared radio EQ" to "Radio EQ" and removed the site-wide wording from that member-facing description.
- Added independent per-user filters to the Web Radio **Who's On** and **Call** lists.
- Who's On filters: All on my channel, Listening, Transmitting, In Call, Available.
- Call filters: All Online, My Channel, Available, In Call, Other Channels.
- Each user's filter choice is stored locally per account/browser and restored automatically.
- Filtering is client-side and does not alter channel membership, calls, or radio presence behavior.

- Added a real-time **Who's On** button to the Web Radio. It shows members currently connected to the same channel and automatically reflects channel changes because presence is read from the LiveKit room for that channel.
- Added a **Call** button that lists online radio users across channels, showing their current channel and **In Call** state when applicable.
- Added direct-call signaling with verified callsign/display-name identity, incoming call accept/decline, busy protection, and a private LiveKit voice room for accepted calls.
- Radio display changes to **CALLING — <callsign>** while ringing and **DIRECT — <callsign>** after the call is answered. Each side sees the other member's verified callsign.
- Direct-call status remains visible in the member's normal channel roster as **In Call**; channel presence is not replaced by the direct-call state.
- PTT is disabled locally while a direct call is active to prevent accidental transmission on the normal radio channel.
- Added **Who's On** and **Call** as optional controls in Admin → Web Radio → Layout so either button can be positioned directly on the radio face; footer buttons remain available when not placed on the photo.
- Added the `RadioDirectCall` entity plus `radio-presence` and `radio-direct-call` backend functions.
- Verification: `npm run build` completed successfully from the Base44 sandbox (`/app`).

## 2026-09-23 — Resync Missing Callsigns From User-Linked Database Records

- Admin → Users now checks the legacy User.callsign, canonical Callsign, approved CallsignAccess, and user-owned Profile records when determining whether a member's callsign exists in the database.
- A member whose User.callsign is blank but whose Profile/canonical/approved record contains a callsign is shown as **Found in DB · Not synced** and can be selected for FCC re-verification.
- **Resync all callsigns** now fills a missing User.callsign from Callsign, approved CallsignAccess, or the user's Profile, in that priority order. It never overwrites an existing User.callsign and does not contact the FCC.
- Selected re-verification now also resolves a callsign from the user's Profile when the legacy field is blank, so admins can select and re-verify members whose callsign exists elsewhere in the database.
- The live database check found 42 members with an empty/None User.callsign; 1 of those currently has a callsign stored in the member's Profile record.
- Other call-sign-bearing activity records are not used as automatic ownership sources because fields such as contact logs and check-ins can refer to another operator rather than the account holder.
- Verification: source changes were committed to GitHub and re-read. No FCC re-verification or browser build/production deployment was run.
## 2026-09-23 — Prevent Re-verification of Members With No Callsign

- Admin → Users no longer shows the row-level **Reverify** action or allows selection for **Re-verify selected** when a member has no legacy or approved/canonical callsign available.
- Members with a missing callsign remain visible and can be filtered with **Show Missing (N)**, but they must have a callsign before FCC verification can be performed.
- **Resync all callsigns** remains the separate repair path for members whose callsign exists in an approved/canonical record but is missing from `User.callsign`.
- Verification: re-read the updated Admin Users source after the edit. No browser build or production deployment was run.

## 2026-09-23 — Clarify Admin Callsign Selection and Missing Members

- Admin → Users now lets administrators filter directly to **Show Missing (N)** members in addition to the broader **Review Callsign Issues** view.
- Members with no legacy, approved, or canonical callsign are clearly marked **Missing** and cannot be selected for FCC re-verification until a callsign exists.
- Members who do have a callsign can still be selected individually with the existing **Re-verify selected** workflow.
- **Resync all callsigns** remains separate and only fills a missing `User.callsign` from an existing canonical/approved callsign; it does not perform FCC verification.
- Verification: re-read the updated Admin Users source after the edit. No browser build or production deployment was run.

## 2026-09-23 — Clarify Callsign Issue vs Missing Callsign Notice Counts

- Admin → Users now distinguishes the broader **callsign attention** count from the narrower **actually missing callsign** count.
- The amber warning can include unverified or non-active callsigns, while **Notify missing callsigns** only targets members with no callsign in the User record, approved CallsignAccess, or canonical primary-user Callsign record.
- The missing-notice dialog now explains why its count can be lower than the broader callsign attention count.
- The existing selected-member **Re-verify** workflow remains separate and lets administrators choose exactly which members are checked against the FCC.
- Verification: re-read the updated Admin Users and admin-api source after the edit. No browser build or production deployment was run.

## 2026-09-23 — Missing Callsign Member Notice

- Added **Notify missing callsigns** to Admin → Users.
- The action only targets non-staff, non-blocked members who have no usable `User.callsign` and no callsign in an approved `CallsignAccess` or canonical primary-user Callsign record.
- Each notice is delivered as an in-app message and an email when the member's notification settings allow email delivery.
- The notice asks the member to re-enter or re-verify the callsign within 7 days and directs users with problems to the Repeater Nation Discord or **support@repeaternation.com**, asking them to include their email, callsign, and username.
- The sent notice stores a 7-day deadline on the User record for later enforcement/audit use.
- Existing **Re-verify selected** remains available for administrators to choose individual members for FCC re-verification; the missing-callsign notice is intentionally separate from re-verification.
- No automatic suspension job was added in this change; the notice records the deadline so enforcement can be added without changing the notification workflow.
- Verification: source was re-read after the update. No browser build or production deployment was run.

## 2026-09-23 — Restore Admin Users Re-verification Selection UI

- Restored the complete `src/pages/admin/AdminUsers.jsx` source after an accidental truncation caused the Admin → Users page to fail loading.
- Kept the selectable **Re-verify selected** workflow so administrators can choose exactly which members to re-verify.
- Removed the temporary per-user **Resync selected** controls; **Resync all callsigns** remains separate and only repairs missing callsign fields without verification.
- Restored the valid selected-reverification toast template expression that was causing the `Unexpected token` parser error.
- Verification: re-read the restored source and confirmed the selected re-verification workflow and Resync-all workflow are present, with no selected-resync references remaining. No browser build or production deployment was run.

## 2026-09-23 — Fix Admin Users Re-verification UI Parser Error

- Fixed a malformed template-literal expression in `src/pages/admin/AdminUsers.jsx` that caused the Admin → Users page to fail loading with `Unexpected token, expected ","`.
- The Admin Users selection workflow now has one clear **Select** control for choosing exactly which members will be re-verified.
- Removed the separate **Resync selected** selection controls from the table so **Resync all callsigns** remains clearly separate and only repairs missing callsign fields.
- Verified the committed source no longer contains the malformed toast syntax or stale selected-resync references, and that both **Re-verify selected** and **Resync all callsigns** remain present.
- No browser build or production deployment was run in this step.

## 2026-09-23 — Admin Callsign Re-verification Uses FCC Only

- Admin **Re-verify**, **Re-verify selected**, and **Re-verify all callsigns** now use the official FCC License View lookup path instead of the broader provider fallback chain.
- A callsign is marked **verified** when the FCC lookup finds an exact matching callsign with an active status and a qualifying **GMRS or HAM** service.
- FCC lookup failures/unavailability do not silently mark a member invalid.
- Existing selective member selection remains available in Admin → Users; **Resync** remains separate and only fills missing callsigns without verification.
- Verification: re-read the updated FCC helper, admin API, Admin Users UI, and development log. No live FCC verification transaction or browser build was run.

## 2026-09-23 — Prevent Profile Settings from Overwriting Callsign Verification

- Fixed a data-integrity bug in `src/pages/Profile.jsx` where saving unrelated profile settings could write the Profile entity's stale `license_status` and `callsign` values back to the authoritative User record.
- This could leave users with `callsign_verified: true` while their `license_status` was reset to **Pending**, which matched the inconsistent live records found during inspection.
- Profile saves now update only profile/settings fields on the User record; callsign and license verification data remain controlled by the Callsign Management / verification flows.
- Removed the old profile-save-triggered repeater-link side effect because callsign changes are no longer managed from the generic Profile form.
- Live inspection found 23 User records currently showing **Pending** despite `callsign_verified: true`; 42 Users have no legacy `User.callsign`. The 42 missing users currently have no canonical Callsign ownership record or approved CallsignAccess from which a safe resync can derive a callsign.
- The canonical Callsign table contains 1,498 legacy **pending** records with no last-check timestamp/source; these are not 1,498 pending users.
- Verification: inspected live User, Profile, Callsign, CallsignAccess, and AuditLog data and traced the Profile save path. GitHub source updated; no browser build or production deployment was run in this step.

## 2026-09-23 — Self-Service Callsign Re-verification

- Added a **Re-verify** button to the Callsign Management page for both primary/owned callsigns and approved authorized callsigns.
- Re-verification is performed server-side through the existing callsign verification provider, so the result is not trusted from the browser.
- The canonical Callsign record is refreshed with the latest verification status, license information, expiration, service, and last-check timestamp.
- Approved users sharing the callsign have their verification status synchronized with the refreshed license status, while users with another independently verified callsign are not unnecessarily downgraded.
- Users can only re-verify callsigns they own or have approved access to; admins retain access as well.
- Verification: re-read the changed Callsign Management and callsign-manage source. No browser build or live verification transaction was run.

## 2026-09-23 — Publish Public POTA and Net Control Plans to Events

- Public POTA activations now automatically create or update a matching **POTA Activation** entry on the community Events page.
- Public Net Control sessions now automatically create or update a matching **Net Control** entry on the Events page when scheduled/edited.
- Private POTA activations and private Net Control sessions are not published to the public Events page.
- Source records store the linked Event ID so editing does not create duplicate Events; changing a public record to private removes its linked Event.
- Event records retain `source_type` and `source_id` so the origin can be identified later.
- No existing POTA activations, Net Control sessions, or Event records were migrated automatically.
- Verification: re-read the changed source/entity files after the updates. No browser build or live production transaction was run.

## 2026-09-23 — Fix Admin Tags Preview Syntax Error

- Fixed a malformed literal `\\n` sequence in `src/pages/admin/AdminTags.jsx` that caused the Vite parser error `Expecting Unicode escape sequence \\uXXXX`.
## 2026-09-27 — Web Radio Rate-Limit Optimization Pass
- Optimized `radio-presence` to stop scanning the `RadioDirectCall` entity during every presence refresh; LiveKit is now the source of truth for active direct-call participants.
- `radio-presence` skips empty LiveKit rooms before requesting participant lists, reducing unnecessary voice-provider traffic.
- Optimized `radio-direct-call` list/reconciliation to inspect only calls involving the requesting user instead of globally scanning up to 100 records per request.
- Reduced Web Radio floor-state safety polling from 8 seconds to 15 seconds; realtime subscription remains the primary update path.
- Reduced direct-call/presence refresh from 5 seconds to 10 seconds and caller state polling from 1 second to 2 seconds.
- These changes target request amplification that can contribute to Base44 rate limiting while preserving normal radio, PTT, presence, and direct-call behavior.
- No FCC imports were resumed and unrelated functionality was not changed.

## 2026-09-27 — Fix Admin Callsign Account Synchronization

- Fixed Admin → Users → Set Callsign so it finds the member's canonical Callsign record even when older records have a missing radio_service.
- The canonical Callsign record now receives the selected GMRS/HAM service whenever the callsign is changed.
- The member's User.callsign and license_service fields are now synchronized whenever an existing canonical Callsign record is edited, including changes that intentionally remain pending verification.
- Manual verification continues to set callsign_verified=true and license_status=Active; normal callsign edits continue to remain pending.
- This specifically addresses accounts such as hillbillyhession where the Callsign record existed but had no radio service, causing the admin edit path to fall through and leave the account out of sync.
- No unrelated callsign, FCC lookup, access-request, or radio functionality was changed.
## 2026-09-27 — Direct Call Screen Styling

- Updated the active Direct Call dialog to visually follow the radio callsign display treatment: compact dark display, prominent monospace callsign, and clear DIRECT/CALLING state.
- Kept the existing call state, LiveKit behavior, controls, and end-call action unchanged.
- Build verified successfully.
## 2026-09-27 — Radio Member Dialog Styling

- Restyled Call a Member and Whos On — Nation Wide dialogs to match the radio/callsign display treatment.
- Kept filters, member lists, call actions, and presence behavior unchanged.


## 2026-09-27 — Remove API Promotion From Home Page

- Removed the public “Build on Repeater Nation” API promotion section from the home page.
- Removed the API description, API docs button, registration button in that section, and curl/API example.
- Kept the API itself, API documentation page, API management, and all unrelated home page content unchanged.
- GitHub commit: 2b995f678ca682e7eda0b916547508cde5047792

## 2026-09-27 — Emergency Map Fire Perimeter Layer

- Expanded the Emergency & Situational Awareness map with current wildfire perimeter data from the NIFC WFIGS interagency perimeter service.
- Added a Wildfire Perimeters map layer with fire-name, acreage, category, and perimeter details.
- Added an active fire perimeter count to the command-center summary cards.
- Kept NWS alerts, USGS earthquakes, GMRS/HAM repeaters, location filtering, refresh behavior, and existing tools unchanged.
- Production build verified successfully.

## 2026-09-27 — Emergency Map ZIP Search

- Added a public ZIP-code search to the Emergency & Situational Awareness map.
- Users can enter a U.S. 5-digit ZIP code to center the emergency map and load nearby alerts, earthquakes, shelters, fire perimeters, and GMRS/HAM repeaters using the selected radius.
- Added server-side ZIP geocoding so users do not need to share browser location.
- Preserved Find My Location as an optional alternative and kept existing emergency layers unchanged.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Icon Markers

- Replaced the circular point markers on the Emergency & Situational Awareness map with recognizable icon markers for the user's location, emergency shelters, earthquakes, and GMRS/HAM repeaters.
- Kept wildfire perimeters as geographic polygons because they represent the actual affected area rather than a point location.
- Preserved all existing popups, layers, filtering, refresh behavior, and emergency data sources.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Wildfire Freshness Enforcement

- Added a strict 24-hour freshness rule to wildfire incident and perimeter data before it reaches the Emergency Map.
- Fire records without a valid timestamp, or with the relevant update/perimeter timestamp older than 24 hours, are automatically excluded from the map and wildfire list on the next sync.
- Newly discovered wildfire incidents remain eligible for 24 hours based on their discovery timestamp even if their modification timestamp is not yet updated.
- Existing weather alerts, earthquakes, repeaters, shelters, ZIP search, radius filtering, and map behavior remain unchanged.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Wildfire Incident Feed

- Added the NIFC WFIGS current incident-location feed alongside the existing current fire-perimeter feed.
- Added live wildfire incident markers with fire name, acreage, containment, location, discovery time, and update time.
- Added server-side radius filtering for wildfire incident locations so ZIP/location searches can populate nearby fires on the map.
- Kept the existing NIFC perimeter polygons and emergency layers unchanged.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Population Runtime Fix

- Fixed the Emergency Map backend runtime error `Cannot access 'hasCenter' before initialization` introduced by the population filtering update.
- Moved center-state initialization before the NWS and wildfire geographic filters that use it.
- Verified the application production build successfully.
- No unrelated emergency-map or Repeater Nation functionality was changed.

## 2026-09-28 — Emergency Map Filter Visibility Fix

- Updated the Map Filters grid to use explicit responsive breakpoints so all ten layer controls remain visible across desktop, tablet, and mobile widths.
- Made each filter button full-width within its grid cell to prevent controls from being compressed or visually hidden.
- Preserved all existing map layers, filter behavior, marker rendering, and unrelated Repeater Nation functionality.
- Production build verified successfully.

## 2026-09-28 — Emergency Map Weather, Air Quality, and Wildfire Population Fix

- Improved Nearby Weather Stations population by requesting a larger NWS station set, retaining stations even when an individual latest-observation request fails, and filtering/sorting stations by the selected radius.
- Limited latest NWS observation requests to the nearest 24 returned stations to reduce upstream request amplification while preserving nearby station coverage.
- Removed overly aggressive freshness filtering from the NIFC current wildfire perimeter and current incident feeds so active fires are not discarded simply because an individual timestamp is older than 24 hours.
- Relaxed AirNow PM2.5 contour freshness to 12 hours while continuing to use the selected map area and radius for the ArcGIS spatial query.
- Added a non-blocking upstream-source status notice when one or more official feeds fail during a refresh; successfully returned layers remain usable.
- Added a frontend geometry guard for AirNow zones before rendering them as Leaflet GeoJSON layers.
- Preserved existing map layers, marker styling, controls, radius behavior, and unrelated Repeater Nation functionality.

## 2026-09-28 — Emergency Map Population Filtering Fix

- Fixed Emergency Map ZIP validation so valid 5-digit ZIP searches are accepted by both the browser and backend.
- Added geographic filtering for NWS alert polygons when a ZIP/location and radius are selected, while retaining alerts without geometry.
- Added geographic filtering for wildfire perimeter polygons so the selected area no longer receives an unbounded nationwide perimeter set.
- Preserved the existing server-side radius filtering for repeaters, earthquakes, shelters, and wildfire incidents.
- Preserved all map styling, layers, controls, refresh behavior, data sources, and unrelated Repeater Nation functionality.

## 2026-09-27 — Emergency Map Live Data Sync Optimization

- Updated the Emergency & Situational Awareness backend to sync and return nearby repeater, earthquake, and shelter data based on the selected ZIP/location and radius before sending it to the map.
- Added server-side distance filtering and sorting so the map receives the relevant nearby records instead of loading the full datasets into the browser.
- Preserved NWS weather alerts and NIFC wildfire perimeter coverage, along with the existing 25/50/100/250-mile controls and 60-second refresh cycle.
- Production build verified successfully.

## 2026-09-27 — Emergency Earthquake Popup Formatting Fix

- Fixed the earthquake map popup so the Updated timestamp and distance render as actual separate lines instead of displaying a literal <br /> string.
- Preserved the earthquake time, update time, magnitude, location, and distance information.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Performance and Event Timestamps

- Reduced Emergency Map client-side rendering load by limiting visible repeater and shelter markers to the nearest 500 records and limiting wildfire perimeter rendering to 150 records.
- Added an Active Wildfires list so fire names, acreage/category, and perimeter update timestamps are visible without opening each map polygon.
- Added earthquake event time and update time to earthquake map popups.
- Added weather alert issued/effective time and expiration time to alert cards and the selected-alert detail panel.
- Added wildfire perimeter update timestamps to map popups and the wildfire list.
- Preserved the existing ZIP search, location search, emergency layers, icons, data sources, and unrelated Repeater Nation tools.
- Production build verified successfully.

## 2026-09-27 — Emergency Map Shelter Layer

- Added live FEMA ESF6 open-shelter data to the Emergency & Situational Awareness backend.
- Added an Emergency Shelters map layer with shelter status, address, and distance when location is enabled.
- Added nearby shelter count and shelter filtering to the selected radius.
- Kept existing emergency alerts, earthquakes, wildfire perimeters, repeaters, and unrelated tools unchanged.
- Production build verified successfully.

## 2026-09-27 — Emergency & Situational Awareness Map

- Added a new public `/tools/emergency` command-center tool inspired by the capability set of modern emergency situational-awareness maps, without copying third-party branding or UI.
- Added live National Weather Service active alerts with map polygons, severity, affected areas, expiration times, and selectable alert details.
- Added live USGS earthquake data for the previous day, with magnitude-based map markers and distance filtering when a user shares location.
- Added the Repeater Nation GMRS/HAM repeater network as a live infrastructure layer, with distance sorting and 25/50/100/250-mile radius filters.
- Added Find My Location, layer toggles, manual refresh, and 60-second automatic refresh.
- Added `/tools/emergency` to the public Operator Tools directory.
- Added the `emergency-intel` backend function to aggregate official NWS/USGS data and Repeater Nation repeater data server-side.
- Kept existing Weather, Flight Radar, SDR, GPS, GMRS, HAM, and repeater directory features unchanged.
- Production build verified successfully.


## 2026-09-30 — Public Member Directory 500 Fix

- Fixed the public member directory backend function returning HTTP 500 when either the User or Profile entity query temporarily failed.
- User and Profile loading are now independent and best-effort so a failure in one dataset no longer prevents healthy member records from rendering.
- The directory can now build members from Profile records alone when User records are temporarily unavailable, while still using User data when available.
- Unrelated statistics remain best-effort and cannot cause the member directory itself to fail.
- Preserved hidden-account filtering, callsign verification status, GMRS/HAM service information, member profiles, and existing directory response structure.
- Production frontend build verified successfully with `npm run build`.
- GitHub commit: 5903e14a2221fc4f0ab07998e996c8577f4adb7b
