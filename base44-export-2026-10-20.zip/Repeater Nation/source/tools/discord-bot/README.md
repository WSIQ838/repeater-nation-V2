# Discord bot (moved)

The program that keeps the Repeater Nation Discord bot online now lives in its
own repository: <https://github.com/WSIQ838/repeater-nation-discord-bot>.

The website itself doesn't need it: Discord events are created, updated and
removed by the `discord-events-sync` function. The bot program only makes the
bot show as online in Discord.
